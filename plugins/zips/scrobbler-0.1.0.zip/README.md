# Scrobbler for YouTube Music Desktop

A plugin for [YouTube Music Desktop](https://github.com/Ariazonaa/ytmusic-desktop)
that sends what you listen to to [ListenBrainz](https://listenbrainz.org) or
[Last.fm](https://www.last.fm).

- A track counts once half of it was heard, or four minutes, whichever comes
  first. Tracks shorter than 30 seconds do not count. These are Last.fm's rules.
- What plays now is shown on your profile as it starts (can be switched off).
- Listens that cannot be sent, for instance offline, are kept and sent later.

## Install

In the app's settings window, "Find plugins" lists it. Or download the zip
from the releases and use "Install from a zip file". Then switch it on.

## Set up

**ListenBrainz:** choose it as the service and paste your user token from
listenbrainz.org, Settings, "User token".

**Last.fm:** Last.fm wants every program that scrobbles to have its own API
account. Create one at [last.fm/api/account/create](https://www.last.fm/api/account/create)
(any name will do), choose Last.fm as the service, enter the API key and the
shared secret, then click "Scrobbler" in YouTube Music and "Sign in to
Last.fm". Allow access in the browser that opens and click "Done".

## What it may do

- `music.read`: the playing track, to know what to send.
- `network` to `api.listenbrainz.org`, `ws.audioscrobbler.com` and
  `www.last.fm` (the sign-in page): nothing else is contacted.
- `ui.inject`: the Scrobbler button and its panel.

What is sent: title, artist, album, length, when you started listening and, to
ListenBrainz, the link to the track on YouTube Music.

## Develop

`node --test test/` runs the tests. `scrobble.js` holds what is sent when;
`index.js` talks to the app through `ytmd`.

MIT license.
