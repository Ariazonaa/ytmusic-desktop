/// <reference path="./ytmd.d.ts" />
// Scrobbler: tells ListenBrainz or Last.fm what you listen to. A track
// counts once half of it was heard, or four minutes. Listens that cannot be
// sent are kept and sent later.
import { LASTFM_API, Listening, lastFmBody, lastFmTrackParams, listenBrainzRequest } from "./scrobble.js";

const RETRY_SECONDS = 60;
const MAX_PENDING = 100;

const listening = new Listening();
let settings = await ytmd.settings.getAll();
/** A Last.fm token waiting for the user to allow access in the browser. */
let lastFmToken = null;
let status = "";
let last = "";
let tick = 0;

ytmd.on("settingsChange", (values) => {
  settings = values;
  render();
});

// ---- Sending -------------------------------------------------------------

async function sendListenBrainz(track, kind) {
  const [url, request] = listenBrainzRequest(settings.listenbrainzToken, track, kind);
  const { status: code, data } = await ytmd.net.request(url, request);
  if (code === 401) throw new Error("ListenBrainz does not know this token");
  if (code !== 200) throw new Error(`ListenBrainz answered ${code}${data?.error ? `: ${data.error}` : ""}`);
}

async function lastFmCall(params) {
  const body = lastFmBody(params, settings.lastfmSecret);
  const { status: code, data } = await ytmd.net.request(LASTFM_API, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  if (data?.error) throw new Error(`Last.fm: ${data.message ?? data.error}`);
  if (code !== 200) throw new Error(`Last.fm answered ${code}`);
  return data;
}

async function sendLastFm(track, kind) {
  if (!settings.lastfmSession) throw new Error("not signed in to Last.fm");
  const method = kind === "single" ? "track.scrobble" : "track.updateNowPlaying";
  await lastFmCall(lastFmTrackParams(method, track, settings.lastfmApiKey, settings.lastfmSession));
}

/** Sends a listen (`single`) or what plays now (`playing_now`) to the chosen service. */
async function send(track, kind) {
  if (settings.service === "listenbrainz" && settings.listenbrainzToken) return sendListenBrainz(track, kind);
  if (settings.service === "lastfm") return sendLastFm(track, kind);
  throw new Error("no service set up");
}

function readPending() {
  try {
    const list = JSON.parse(settings.pending || "[]");
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

async function keepForLater(track) {
  const pending = [...readPending(), track].slice(-MAX_PENDING);
  await ytmd.settings.update({ pending: JSON.stringify(pending) });
}

async function scrobble(track) {
  try {
    await send(track, "single");
    last = `${track.artist} – ${track.title}`;
    status = "";
  } catch (error) {
    status = String(error.message ?? error);
    if (settings.service) await keepForLater(track);
  }
  render();
}

/** Sends what could not be sent before, oldest first, as long as it works. */
async function retry() {
  const pending = readPending();
  if (pending.length === 0 || !settings.service) return;
  let sent = 0;
  for (const track of pending) {
    try {
      await send(track, "single");
      sent += 1;
    } catch {
      break;
    }
  }
  if (sent > 0) await ytmd.settings.update({ pending: JSON.stringify(pending.slice(sent)) });
  render();
}

// ---- Listening -----------------------------------------------------------

async function started(song) {
  if (!song) return listening.start(null, 0);
  const videoId = await ytmd.music.getVideoId();
  const state = await ytmd.music.getPlaybackState();
  listening.start(
    { title: song.title, artist: song.artist, album: song.album ?? "", videoId, duration: state?.durationSeconds ?? null },
    Math.floor(Date.now() / 1000),
  );
  const ready = settings.service === "listenbrainz" || (settings.service === "lastfm" && settings.lastfmSession);
  if (settings.nowPlaying !== false && ready) {
    // A wrong token shows here at once, not only when the first listen counts.
    send(listening.track, "playing_now").then(
      () => {
        if (status) {
          status = "";
          render();
        }
      },
      (error) => {
        status = String(error.message ?? error);
        render();
      },
    );
  }
}

ytmd.on("songChange", (song) => void started(song));
await started(await ytmd.music.getCurrentSong());

setInterval(async () => {
  const state = await ytmd.music.getPlaybackState();
  const counted = listening.tick(state ? !state.paused : false, state?.durationSeconds ?? null);
  if (counted) void scrobble(counted);
  if (++tick % RETRY_SECONDS === 0) void retry();
}, 1000);

// ---- Last.fm sign-in -----------------------------------------------------

async function connectLastFm() {
  if (!settings.lastfmApiKey || !settings.lastfmSecret) {
    status = "Enter the Last.fm API key and shared secret in the plugin's settings first.";
    return render();
  }
  try {
    const answer = await lastFmCall({ method: "auth.getToken", api_key: settings.lastfmApiKey });
    lastFmToken = answer.token;
    await ytmd.net.openInBrowser(`https://www.last.fm/api/auth/?api_key=${encodeURIComponent(settings.lastfmApiKey)}&token=${encodeURIComponent(lastFmToken)}`);
    status = "Allow access in the browser, then click \"Done\" here.";
  } catch (error) {
    status = String(error.message ?? error);
  }
  render();
}

async function finishLastFm() {
  try {
    const answer = await lastFmCall({ method: "auth.getSession", api_key: settings.lastfmApiKey, token: lastFmToken });
    await ytmd.settings.update({ lastfmSession: answer.session.key, lastfmUser: answer.session.name });
    lastFmToken = null;
    status = "";
  } catch (error) {
    status = String(error.message ?? error);
  }
  render();
}

// ---- The panel -----------------------------------------------------------

const style = document.createElement("style");
style.textContent = `
  body { display: flex; flex-direction: column; gap: 12px; }
  p { margin: 0; }
  small { color: rgba(255, 255, 255, 0.6); }
  button { align-self: flex-start; padding: 6px 10px; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 6px; background: #1c1c1c; color: #fff; font: inherit; cursor: pointer; }
  .error { color: #ff8a80; }
`;
document.head.append(style);

function line(text, className) {
  const p = document.createElement("p");
  p.textContent = text;
  if (className) p.className = className;
  return p;
}

function button(label, run) {
  const element = document.createElement("button");
  element.type = "button";
  element.textContent = label;
  element.addEventListener("click", run);
  return element;
}

function render() {
  const parts = [];
  if (settings.service === "listenbrainz") {
    parts.push(line(settings.listenbrainzToken ? "Sending to ListenBrainz." : "Enter your ListenBrainz token in the plugin's settings."));
  } else if (settings.service === "lastfm") {
    if (settings.lastfmSession) {
      parts.push(line(`Sending to Last.fm as ${settings.lastfmUser}.`));
      parts.push(button("Sign out", () => void ytmd.settings.update({ lastfmSession: "", lastfmUser: "" })));
    } else if (lastFmToken) {
      parts.push(button("Done", () => void finishLastFm()));
    } else {
      parts.push(button("Sign in to Last.fm", () => void connectLastFm()));
    }
  } else {
    parts.push(line("Choose ListenBrainz or Last.fm in the plugin's settings."));
  }
  const pending = readPending().length;
  if (last) parts.push(line(`Last sent: ${last}`));
  if (pending > 0) parts.push(line(`${pending} not sent yet; they go when the service can be reached.`));
  if (status) parts.push(line(status, "error"));
  document.body.replaceChildren(...parts);
}

render();

let open = false;
ytmd.on("panelClose", () => (open = false));
await ytmd.ui.addNavButton("Scrobbler", async () => {
  open = !open;
  await (open ? ytmd.ui.showPanel("Scrobbler") : ytmd.ui.hidePanel());
});
