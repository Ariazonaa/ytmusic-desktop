// What to send to ListenBrainz and Last.fm, and when a track counts. Kept
// apart from index.js so that it can be tested outside the app.
import { md5 } from "./md5.js";

/** A track counts once heard this long: half of it, at most four minutes. Shorter tracks than 30 s never count. */
export function scrobbleAfter(durationSeconds) {
  if (!(durationSeconds > 30)) return null;
  return Math.min(durationSeconds / 2, 240);
}

/** The track that plays and how much of it was heard. */
export class Listening {
  constructor() {
    this.track = null;
    this.heard = 0;
    this.counted = false;
  }

  /** A new track starts at `startedAt` (Unix seconds). */
  start(track, startedAt) {
    this.track = track ? { ...track, startedAt } : null;
    this.heard = 0;
    this.counted = false;
  }

  /**
   * One more second heard, if `playing`. Returns the track once it counts as
   * listened to, else null.
   */
  tick(playing, durationSeconds) {
    if (!this.track || !playing || this.counted) return null;
    this.heard += 1;
    const after = scrobbleAfter(durationSeconds ?? this.track.duration);
    if (after === null || this.heard < after) return null;
    this.counted = true;
    return { ...this.track, duration: durationSeconds ?? this.track.duration };
  }
}

const LB = "https://api.listenbrainz.org/1/submit-listens";

/** The request to ListenBrainz for a listen, or for what plays now. */
export function listenBrainzRequest(token, track, kind) {
  const metadata = {
    artist_name: track.artist,
    track_name: track.title,
    ...(track.album ? { release_name: track.album } : {}),
    additional_info: {
      media_player: "ytmusic-desktop",
      submission_client: "ytmd-scrobbler",
      ...(track.videoId ? { origin_url: `https://music.youtube.com/watch?v=${track.videoId}` } : {}),
      ...(track.duration ? { duration_ms: Math.round(track.duration * 1000) } : {}),
    },
  };
  const listen = kind === "single" ? { listened_at: track.startedAt, track_metadata: metadata } : { track_metadata: metadata };
  return [
    LB,
    {
      method: "POST",
      headers: { Authorization: `Token ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ listen_type: kind, payload: [listen] }),
    },
  ];
}

export const LASTFM_API = "https://ws.audioscrobbler.com/2.0/";

/** Last.fm's signature: the parameters sorted by name, joined, with the secret, through MD5. */
export function lastFmSignature(params, secret) {
  const joined = Object.keys(params)
    .filter((key) => key !== "format" && key !== "callback")
    .sort()
    .map((key) => key + params[key])
    .join("");
  return md5(joined + secret);
}

/** A signed Last.fm call, as the body of a POST. */
export function lastFmBody(params, secret) {
  const signed = { ...params, api_sig: lastFmSignature(params, secret), format: "json" };
  return new URLSearchParams(signed).toString();
}

/** The Last.fm calls for a scrobble and for what plays now. */
export function lastFmTrackParams(method, track, apiKey, session) {
  const params = { method, api_key: apiKey, sk: session, artist: track.artist, track: track.title };
  if (track.album) params.album = track.album;
  if (track.duration) params.duration = String(Math.round(track.duration));
  if (method === "track.scrobble") params.timestamp = String(track.startedAt);
  return params;
}
